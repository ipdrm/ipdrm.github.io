IPDRM16 Web Site Source
============================================

Based on the HURST15 SC workshop template.

This is the source code for the IPDRM16 web site, which uses
[Jekyll](http://jekyllrb.com) and
[GitHub pages](https://pages.github.com).

The site uses the [t413.com/SinglePaged](http://t413.com/SinglePaged)
theme for Jekyll.


## How to edit this site

All you have to do to edit this site is clone it, edit either
`_config.yml` or the `_posts/*.md` files, and push it back to GitHub.
There are [many more details here](http://t413.com/SinglePaged).
