---
title: "Committees"
bg: blue 
color: white
style: left
fa-icon: users
icon-title: true
---
## General Chairs

* Shuaiwen Leon Song, Pacific Northwest National Laboratory
* Todd Gamblin, Lawrence Livermore National Laboratory

## Publicity Chair

* Jingweijia Tan, University of Houston

## Proceeding Chair

* Albert Sidelnik, NVIDIA Research

## Web Chair

* Joseph Manzano, Pacific Northwest National Laboratory

## Program Committee

* Ananta Tiwari, San Diego Supercomputing Center, USA
* Huiyang Zhou, North Carolina State University, USA
* Felix Wolf, German Research School For Simulation Sciences, Germany
* Lizy Kurian John, University of Texas, Austin, USA
* Jeff Young, Georgia Tech, USA
* Benoit Meister, Reservoir Labs, USA
* Suren Byna, Lawrence Berkley National Lab, USA
* Siva Hari, NVIDIA Research, USA
* Zhijia Zhao, University of California, Riverside, USA
* Holger Fröning, Ruprecht-Karls University of Heidelberg, Germany
* Boyana Norris, University of Oregon, USA
* Prasanna Balaprakash, Argonne National Laboratory, USA
* Xu Liu, College of William and Mary, USA
* Bo Wu, Colorado School of Mines, USA
* Dipanjan Sengupta, Georgia Tech, USA
* Ang Li,  Eindhoven University of Technology, Netherlands
* Marc Cass, Barcelona Supercomputing Center, Spain
* Devesh Tiwari, Oak Ridge National Laboratory, USA
